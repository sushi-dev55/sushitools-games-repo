-- 3504560's Lua and Manifest Created by Morrenus
-- Tomba! 2: The Evil Swine Return Special Edition
-- Created: December 15, 2025 at 17:30:26 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3504560) -- Tomba! 2: The Evil Swine Return Special Edition
-- MAIN APP DEPOTS
addappid(3504561, 1, "0d1607b31ce8b88c9edd5436e868bb20e15679e1fa1456ffd98846e8a593a808") -- Depot 3504561
setManifestid(3504561, "5311227181888192555", 3538197227)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)