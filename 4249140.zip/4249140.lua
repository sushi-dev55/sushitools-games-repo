-- Made by F1uxin (UserID:965053505901588521), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/NmmpgnAgen)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:965053505901588521)
-- And if you have any questions feel free to dm on discord (UserID:965053505901588521)

-- Socials: https://guns.lol/f1uxin

-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)

-- Main stuff to add your game.
addappid(4249140)
addappid(4249141,0,"2a97406feb503f79a2659d4eb10ded1fcc7e960755f4c6734cafe23a97cbfc0b")
setManifestid(4249141,"4796721454440631002")
addappid(4249142,0,"28a1d86a2a3e8b911afedb883fe2e799c427aed72e842e210b3d572edcc11e95")
setManifestid(4249142,"8317111034436746209")
addappid(4249143,0,"3b71cda097300405475593b676983749db2088db265180279be47ff5ce7e8b0a")
setManifestid(4249143,"8715077015752662662")