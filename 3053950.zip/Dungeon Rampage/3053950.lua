-- 3053950's Lua and Manifest Created by Morrenus
-- Dungeon Rampage
-- Created: December 07, 2025 at 02:09:33 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3053950) -- Dungeon Rampage
-- MAIN APP DEPOTS
addappid(3053951, 1, "ea08b64bcd0b4a1d3e0f98a73635dc2bb201af53c6554067986e6bb0c06e9e8b") -- Depot 3053951
setManifestid(3053951, "84745987742947354", 151693246)