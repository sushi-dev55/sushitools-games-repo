-- 1699230's Lua and Manifest Created by Morrenus
-- Hail to the Rainbow
-- Created: December 01, 2025 at 07:28:02 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1699230) -- Hail to the Rainbow
-- MAIN APP DEPOTS
addappid(1699231, 1, "8e5a43546b9a39b28212488520661b6983e198bd6ee53c4f80119f738fb93bd1") -- Depot 1699231
setManifestid(1699231, "8639571768953797278", 15531865628)