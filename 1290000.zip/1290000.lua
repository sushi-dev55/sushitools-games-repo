-- Made by @f1uxin, If you would like to check out my discord server here's a link : https://discord.gg/NmmpgnAgen
-- In my server we help with mani & lua files, fixes, and honestly just anything about piracy,
-- You can dm me "f1uxin" on discord if you have any questions or anything I'm normally pretty active, and enjoy!
-- If you want to redistribute/share these files please add and dm "f1uxin" on discord to talk more, me and my friend pay for these games with our own money, we do get games cheaper but its still money that we have and are spending so it sucks when people steal/don't credit me at all.

-- P.S On some socials you may find another person with a close name to me, its "f1uxin sells" or "f1uxins shop" any accounts like that are not mine, i do not sell anything, everything I show is free.

-- P.S. #2. This one is important, you see the "setManifestid" lines below right? If you want your game to "auto update" put "--" without the "" Infront of each "setManifestid" or you can completely remove those lines but that is not recommended, then just save this file, and add it however you add mani & lua files. Example "--setManifestid"

-- Guns.lol link (guns.lol is like linktree, its just my socials) : https://guns.lol/f1uxin


-- MAIN APPLICATION
addappid(1290000)
addappid(1290001,0,"e1f9c3c77548607fe5ec8fd39e594dc6926e14264a94ac69596edc9a4c1c5d2d")
setManifestid(1290001,"1220066493861247784")
addappid(2088510)
addappid(2088511)
addappid(2236950,0,"57599a6ca6afdc5976b0a58f3b1fcb3112af8c0a49e22deaa617135d4fdbbe0c")
setManifestid(2236950,"5797815025118046867")
addappid(2464650,0,"aa72be5f1b0234d84153fd284facc44dca5863b88713f127f15b594ebaef6984")
setManifestid(2464650,"7910315142882863444")
addappid(2593910,0,"59c05971823cd8abd340351687bd5fb89d6ef70ee901b16e73d3cdc36b975be4")
setManifestid(2593910,"9115266583198901408")
addappid(2593920,0,"ad003411baaef219c8442fd9a83b29359c7537fb74d5fa472b2d3ccaf12b9afc")
setManifestid(2593920,"8430617064611281586")
addappid(2593930,0,"1114218c44c7c72cef8710a7a4e4f335a6cff4fb36aaa5d44c57e1e4af33793a")
setManifestid(2593930,"9141974814283262715")
addappid(2736310,0,"edc8d287c458dc45aa67761dc2ac255ccb772971d1e8522d4e023f7333024065")
setManifestid(2736310,"491923310737937234")
addappid(2736320,0,"49e417c7af0d5f6e53dfa4576e7610564fc68ed6a3d8009fee06b6ea59720c68")
setManifestid(2736320,"1233812463116222762")
addappid(2736330,0,"22a8358563f081910be407d8b5ea9dc8dd73c68c119d34c2d9f618d520eb262e")
setManifestid(2736330,"2596884068056883832")
addappid(2983890,0,"ba4ae8d51fc2d5967e67e49574c38f050eaff58627ce5829dcdcb0be20fd8652")
setManifestid(2983890,"8738490745880930339")
addappid(2562180,0,"d74d4632fe8e399ed87416813dd465b40bc45462a77d35f69f85413227b63613")
setManifestid(2562180,"6030682696584484659")
addappid(2983900,0,"1420cd0c58565f5997903e49b7a2261e30d70ba5e78f2aebc7cd0806234f598b")
setManifestid(2983900,"8077614349638701324")
addappid(3077590,0,"830871220b6ba45f9820857669f81e11224826d5be12f1b345efa3dd465a5f9e")
setManifestid(3077590,"8259880888867499637")
addappid(3202500,0,"53e33dbab85b3a9db56d327375a1a77dde92c34660e8caf25d32ad03227eb2ea")
setManifestid(3202500,"5392937703851851778")
addappid(3202510)
addappid(2348940)
addappid(3202510,0,"cdfb6525cf03d973b8fd2e05918e4a75b1c5aac212d97aa2091acab9ffd557c4")
setManifestid(3202510,"2171645551738676370")