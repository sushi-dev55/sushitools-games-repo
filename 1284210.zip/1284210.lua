-- Made by @f1uxin, If you would like to check out my discord server here's a link : https://discord.gg/NmmpgnAgen
-- In my server we help with mani & lua files, fixes, and honestly just anything about piracy,
-- You can dm me "f1uxin" on discord if you have any questions or anything I'm normally pretty active, and enjoy!
-- If you want to redistribute/share these files please add and dm "f1uxin" on discord to talk more, me and my friend pay for these games with our own money, we do get games cheaper but its still money that we have and are spending so it sucks when people steal/don't credit me at all.

-- P.S On some socials you may find another person with a close name to me, its "f1uxin sells" or "f1uxins shop" any accounts like that are not mine, i do not sell anything, everything I show is free.

-- P.S. #2. This one is important, you see the "setManifestid" lines below right? If you want your game to "auto update" put "--" without the "" Infront of each "setManifestid" or you can completely remove those lines but that is not recommended, then just save this file, and add it however you add mani & lua files. Example "--setManifestid"

-- Guns.lol link (guns.lol is like linktree, its just my socials) : https://guns.lol/f1uxin


-- MAIN APPLICATION
addappid(1284210) -- Guild Wars 2
addappid(1284211, 1, "15957cae60ac6d6ef2c8d2972c2a77160c6620b01c02dff14ae85510c0b2c5b6") -- Depot 1284211
setManifestid(1284211, "5255010211593888396", 41662721)
addappid(1284212, 1, "3621a9dd9b026862d51a738bbf79f6e3d7e8ac07521d78934c20d8588e00bbbc") -- Depot 1284212
setManifestid(1284212, "8156769810081378411", 78089418608)
addappid(1996840) -- Expansion Starter Pack - Guild Wars 2 Heart of Thorns and Path of Fire
addappid(2008610) -- Guild Wars 2 - End of Dragons Expansion
addappid(2013750) -- Guild Wars 2 Living World
addappid(2450010) -- Guild Wars 2 - Secrets of the Obscure Expansion
addappid(2486290) -- Guild Wars 2 Secrets of the Obscure Prepurchase Rewards
addappid(2982320) -- Guild Wars 2 Janthir Wilds Expansion
addappid(2982330) -- Guild Wars 2 Janthir Wilds Prepurchase Rewards
addappid(3845860) -- Guild Wars 2 Visions of Eternity Prepurchase Rewards
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(3845870) -- Guild Wars 2: Visions of Eternity™ Expansion (unreleased)