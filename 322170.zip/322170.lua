-- Made by @f1uxin, If you would like to check out my discord server here's a link : https://discord.gg/NmmpgnAgen
-- In my server we help with mani & lua files, fixes, and honestly just anything about piracy,
-- You can dm me "f1uxin" on discord if you have any questions or anything I'm normally pretty active, and enjoy!
-- If you want to redistribute/share these files please add and dm "f1uxin" on discord to talk more, me and my friend pay for these games with our own money, we do get games cheaper but its still money that we have and are spending so it sucks when people steal/don't credit me at all.

-- P.S On some socials you may find another person with a close name to me, its "f1uxin sells" or "f1uxins shop" any accounts like that are not mine, i do not sell anything, everything I show is free.

-- P.S. #2. This one is important, you see the "setManifestid" lines below right? If you want your game to "auto update" put "--" without the "" Infront of each "setManifestid" or you can completely remove those lines but that is not recommended, then just save this file, and add it however you add mani & lua files. Example "--setManifestid"

-- Guns.lol link (guns.lol is like linktree, its just my socials) : https://guns.lol/f1uxin


-- MAIN APPLICATION
addappid(322170, 1, "ad9b88bbea506f1fdeada87713d73123f34a9757ec404f69125253369540b6f2") -- Geometry Dash
addappid(322171, 1, "73d09cfe5a697e2e5bf2a2591259e00c715e9dc3376d4a71ff7e915483be399d") -- Geometry Dash Windows
setManifestid(322171, "7678373534998244044", 328749547)
addappid(322172, 1, "6accd00ac7da1a455e3e689eed217adcdcb14198e5dd23b1e553abbed6d5c38e") -- Geometry Dash Mac
setManifestid(322172, "8771064225227566581", 334922897)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)