-- Made by F1uxin, Discord ID:965053505901588521 | Discord Server (TGP | The Galaxy of Pirates): https://discord.gg/VfCxRsFyFe

-- If you're interested in distributing these files please dm me on discord (UserID:965053505901588521) 
-- (I don't care if you send them to a friend or to help someone, just if you add them in your bot or have them widely available then i would like to know.)

-- Socials: https://guns.lol/f1uxin

-- If you have any questions feel free to dm on discord (UserID:965053505901588521)


-- Main stuff to actually add the game, DLCs, & depots.
addappid(2584270, 1, "2b9f4a2124d5757f3d4f46c81c6d4082f3b1d1ac9b3233acf41ddc6b5c15810a") -- Mortal Shell II
addappid(2584271, 1, "bb59e6dc30df8728a4bfcc3129ca9b8284ed3808d42a9a272e65d4904b4bc445") -- Depot 2584271
--setManifestid(2584271, "8675094712350771048", 73091282862)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
--setManifestid(228989, "5753583882400741046", 25674515)