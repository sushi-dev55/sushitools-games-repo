-- Made by @f1uxin, If you would like to check out my discord server here's a link : https://discord.gg/NmmpgnAgen
-- In my server we help with mani & lua files, fixes, and honestly just anything about piracy,
-- You can dm me "f1uxin" on discord if you have any questions or anything I'm normally pretty active, and enjoy!
-- If you want to redistribute/share these files please add and dm "f1uxin" on discord to talk more, me and my friend pay for these games with our own money, we do get games cheaper but its still money that we have and are spending so it sucks when people steal/don't credit me at all.

-- P.S On some socials you may find another person with a close name to me, its "f1uxin sells" or "f1uxins shop" any accounts like that are not mine, i do not sell anything, everything I show is free.

-- P.S. #2. This one is important, you see the "setManifestid" lines below right? If you want your game to "auto update" put "--" without the "" Infront of each "setManifestid" or you can completely remove those lines but that is not recommended, then just save this file, and add it however you add mani & lua files. Example "--setManifestid"

-- Guns.lol link (guns.lol is like linktree, its just my socials) : https://guns.lol/f1uxin


-- MAIN APPLICATION
addappid(546560, 1, "cde316ca02d2d41283eab207b650aff656b435b1a741fa3372331c9dabc214b3") -- Half-Life: Alyx
addappid(546561, 1, "08cfa79618da286194c744565ffd27d916e9a4fdea33fc16f3894fc03ec29957") -- Half-Life: Alyx Content
setManifestid(546561, "6340340699246199351", 71955575627)
addappid(546563, 1, "2adb19a4389e7b997da8b54c9cdbdac86a6c9aa1582e436ab36e87f91c61bcb8") -- Half-Life: Alyx - Windows Binaries
setManifestid(546563, "8142939566738022382", 945180895)
addappid(546564, 1, "42e56a9d859f83e8a4598907e8593c9bc31e73bcdd640fe80f0bf76b6439dedd") -- Half-Life: Alyx - Linux Binaries
setManifestid(546564, "1905868265862275921", 214244652)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- Half-Life Alyx - Workshop Tools (AppID: 1295040)
addappid(1295040)
addappid(1295040, 1, "6c054d059310877e4a4f8d5b3eddb04a03e1e01e83812ccabc50a7f493442935") -- Half-Life Alyx - Workshop Tools - Half-Life: Alyx - Workshop Tools (1295040) Depot
setManifestid(1295040, "5726991073612952032", 2667347898)
addappid(1270090) -- Half-Life Alyx - Index Preorder Items
addtoken(1270090, "3328034734485466667")