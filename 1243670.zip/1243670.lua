-- Made by F1uxin, Discord ID:965053505901588521 | Discord Server (TGP | The Galaxy of Pirates): https://discord.gg/VfCxRsFyFe

-- If you're interested in distributing these files please dm me on discord (UserID:965053505901588521) 
-- (I don't care if you send them to a friend or to help someone, just if you add them in your bot or have them widely available then i would like to know.)

-- Socials: https://guns.lol/f1uxin

-- If you have any questions feel free to dm on discord (UserID:965053505901588521)


-- Main stuff to actually add the game, DLCs, & depots.
addappid(1243670, 1, "58f5fed1a91505f7a172ae420e382cbe055f1749e033892f3955de0fedeb7173") -- Higurashi When They Cry Hou - Ch.8 Matsuribayashi
addappid(1243671, 1, "395a089690816042035e4b206c627b493398905bd2cad25f1d6021e435d52834") -- Higurashi When They Cry Hou - Ch.8 Matsuribayashi Content
--setManifestid(1243671, "3029418828227363700", 663016411)
addappid(1243672, 1, "af8a421081211c4bd1a4a792a51118798b88c24c7bd0beacf6ae95312ec64d64") -- Higurashi When They Cry Hou - Ch.8 Matsuribayashi Depot OSX
--setManifestid(1243672, "4912567542333210545", 676970962)
addappid(1243673, 1, "11ef639d8de2018fef39f9f021e77f667b5cb2ac89d65c65721f28e871256628") -- Higurashi When They Cry Hou - Ch.8 Matsuribayashi Depot Linux
--setManifestid(1243673, "8780997651525317795", 711730046)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
--setManifestid(228990, "1829726630299308803", 102931551)