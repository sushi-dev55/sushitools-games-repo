-- 3694480's Lua and Manifest Created by Morrenus
-- A Game About Feeding A Black Hole
-- Created: December 16, 2025 at 00:00:23 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3694480, 1, "7b1d62583c220a3619f49ec1f24532f0c854dfebfd164670728cc641efb0e65e") -- A Game About Feeding A Black Hole
-- MAIN APP DEPOTS
addappid(3694481, 1, "1ceeda365ed01bb83356761229c2cb119ef51c000d5c4d42d7850541cf4fed3d") -- Depot 3694481
setManifestid(3694481, "4140223316638949761", 229885876)
addappid(3694483, 1, "bd2845a04c5c2ba7d568677d9d591c9904fabd742767184a2127681e2fba009b") -- Depot 3694483
setManifestid(3694483, "8203784842604951941", 320611958)