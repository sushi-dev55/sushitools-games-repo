-- 1520370's Lua and Manifest Created by Morrenus
-- Mon Bazou
-- Created: December 19, 2025 at 05:16:40 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1520370) -- Mon Bazou
-- MAIN APP DEPOTS
addappid(1520371, 1, "75eef3fd6c1168dae8861e584dc3f7a5784592a127eba4bab4246ac1b77053f9") -- MonBazou Content
setManifestid(1520371, "9199965014867118274", 1130111065)