-- 3014320's Lua and Manifest Created by Morrenus
-- OCTOPATH TRAVELER 0
-- Created: December 05, 2025 at 06:19:26 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 3
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3014320) -- OCTOPATH TRAVELER 0
-- MAIN APP DEPOTS
addappid(3014321, 1, "376135a423323c017c43031fbf0c4048cf6ea9a6ca94311cd04879ad9a043491") -- Depot 3014321
setManifestid(3014321, "5303570054134667005", 4568068942)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3576180) -- 0 
addappid(3718180) -- 0 
addappid(3825480) -- OCTOPATH TRAVELER 0 Digital Deluxe Upgrade