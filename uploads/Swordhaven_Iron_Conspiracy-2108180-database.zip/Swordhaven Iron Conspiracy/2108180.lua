-- 2108180's Lua and Manifest Created by Morrenus
-- SWORDHAVEN
-- Created: December 16, 2025 at 22:21:12 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0 (2 excluded)

-- MAIN APPLICATION
addappid(2108180, 1, "96cd098baf7512dc00dd2d141b1f4525c3e39caff321c41194dbd4de508462b3") -- SWORDHAVEN
-- MAIN APP DEPOTS
addappid(2108181, 1, "a37535e60a7271c54be954c0153730a979fc027cad187830c9bd0490f3e53710") -- Depot 2108181
setManifestid(2108181, "6927658868896719030", 14460398319)
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Swordhaven - Magus Tower Pack (AppID: 4205670) - missing depot keys
-- addappid(4205670)
-- Swordhaven - Kings Pack (AppID: 4205680) - missing depot keys
-- addappid(4205680)