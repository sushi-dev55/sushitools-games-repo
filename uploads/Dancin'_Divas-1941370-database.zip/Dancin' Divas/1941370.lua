-- 1941370's Lua and Manifest Created by Morrenus
-- Dancin Divas
-- Created: December 09, 2025 at 17:01:45 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1941370) -- Dancin Divas
-- MAIN APP DEPOTS
addappid(1941371, 1, "f0a8d2d071d0a6fb5242e6fa95343c5b2dca9efd754ce97d5599182341ae5782") -- Depot 1941371
setManifestid(1941371, "2178600762015134574", 471641205)