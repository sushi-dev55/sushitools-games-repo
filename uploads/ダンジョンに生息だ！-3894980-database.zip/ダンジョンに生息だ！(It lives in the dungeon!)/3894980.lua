-- 3894980's Lua and Manifest Created by Morrenus
-- ダンジョンに生息だ！
-- Created: December 17, 2025 at 09:01:32 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3894980) -- ダンジョンに生息だ！
-- MAIN APP DEPOTS
addappid(3894981, 1, "3b482f854e00a0db64ee40b0002053e117ea5e90b50f821d51cb01f2f7e1dc39") -- Depot 3894981
setManifestid(3894981, "2779277160821186154", 47828097)