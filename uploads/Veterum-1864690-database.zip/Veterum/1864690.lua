-- 1864690's Lua and Manifest Created by Morrenus
-- Veterum
-- Created: December 04, 2025 at 11:13:12 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1864690) -- Veterum
-- MAIN APP DEPOTS
addappid(1864691, 1, "32b27da96cc32e9ddfbc4ab4d11a792413fbabb8ab64dec7d912d7402b14b9b5") -- Depot 1864691
setManifestid(1864691, "3347816120719598019", 371861341)