-- 3721680's Lua and Manifest Created by Morrenus
-- Shatterland
-- Created: December 16, 2025 at 09:23:06 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3721680) -- Shatterland
-- MAIN APP DEPOTS
addappid(3721681, 1, "567c40385d661f1b0e47587628e70767b8e32f38c34c2cdab344e769c92cf5a2") -- Depot 3721681
setManifestid(3721681, "5105034650404873718", 2084512230)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)