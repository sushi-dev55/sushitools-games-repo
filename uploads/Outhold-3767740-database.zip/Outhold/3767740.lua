-- 3767740's Lua and Manifest Created by Morrenus
-- Outhold
-- Created: December 13, 2025 at 03:46:06 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3767740) -- Outhold
-- MAIN APP DEPOTS
addappid(3767741, 1, "97fbb25eacb8358b777d45b36c5a08a6cadb9260f44a15944a73764e84c01278") -- Depot 3767741
setManifestid(3767741, "3014343145577408914", 136537443)