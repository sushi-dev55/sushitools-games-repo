-- 561590's Lua and Manifest Created by Morrenus
-- Cricket Captain 2017
-- Created: October 02, 2025 at 01:55:54 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(561590) -- Cricket Captain 2017
-- MAIN APP DEPOTS
addappid(561591, 1, "bb513b641e3f0be7ad6c00a2e4ca715658f2ab253061a50ccd3f43df8d99beca") -- Cricket Captain 2017 Windows
setManifestid(561591, "4802146356081906146", 253270426)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)