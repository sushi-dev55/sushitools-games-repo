-- 1076640's Lua and Manifest Created by Morrenus
-- Cricket Captain 2019
-- Created: October 02, 2025 at 03:20:06 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1076640) -- Cricket Captain 2019
-- MAIN APP DEPOTS
addappid(1076641, 1, "5692c5bf3b958c7d5ecc38eae6d7baebbe128d420a3176d3d8a746d8dfeffb05") -- Cricket Captain 2019 Content
setManifestid(1076641, "8245905034221474326", 256492743)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)