-- 2313700's Lua and Manifest Created by Morrenus
-- Constance
-- Created: November 28, 2025 at 07:15:27 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2313700) -- Constance
-- MAIN APP DEPOTS
addappid(2313701, 1, "96431a8a22bd40bb4eaad78944c3edcc24fa407ee951d461050bc7d4f4ac4cde") -- Depot 2313701
setManifestid(2313701, "8203850263609601768", 1671163103)