-- 2824660's Lua and Manifest Created by Morrenus
-- Old School Rally
-- Created: December 03, 2025 at 19:12:14 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2824660, 1, "25bea5aac06f14c375495315cd7d5af3135eea8f07145250637898f29a09c536") -- Old School Rally
-- MAIN APP DEPOTS
addappid(2824661, 1, "60f3ee3e365512571665fdfec50bd3b1c8f2d4e4fb747a610b4a9b6e83aea870") -- Depot 2824661
setManifestid(2824661, "5204158363707356001", 966806978)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)