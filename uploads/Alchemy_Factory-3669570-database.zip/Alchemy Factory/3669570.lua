-- 3669570's Lua and Manifest Created by Morrenus
-- Alchemy Factory
-- Created: December 13, 2025 at 04:31:23 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3669570) -- Alchemy Factory
-- MAIN APP DEPOTS
addappid(3669571, 1, "fe5844e8b931f2da4fecf3d1663f9fff18c91ec3d6834f9a9ae792a28b4af523") -- Depot 3669571
setManifestid(3669571, "6878886123077479848", 3452306053)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)