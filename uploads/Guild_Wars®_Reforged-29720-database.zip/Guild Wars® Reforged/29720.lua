-- 29720's Lua and Manifest Created by Morrenus
-- Guild Wars® Reforged
-- Created: December 04, 2025 at 08:18:04 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 5
-- Total DLCs: 13

-- MAIN APPLICATION
addappid(29720) -- Guild Wars® Reforged
-- MAIN APP DEPOTS
addappid(29541, 1, "7f93d15c7db86244f86cecadc8137f20f72eddd640ea65297e2f067d0471dde6") -- Guild Wars content
setManifestid(29541, "5668417229069232538", 4167289466)
addappid(29542, 1, "d65c53534c4cf98eefa63b517b1ebd1b983c2c41846e0d55d7837cb1eda51431") -- Guild Wars french
setManifestid(29542, "5992366029106745127", 2396185776)
addappid(29543, 1, "088886029cf89247fa5fc98ed39121aae6b13e7dd9f61eda89bc44569c469798") -- Guild Wars German
setManifestid(29543, "2449735973173310759", 2398566064)
addappid(29544, 1, "32d6a8f3f7e420afc49d460ddc5d840f89281780094a55e9b98691aae327df1d") -- Guild Wars Italian
setManifestid(29544, "4759027866653794960", 2396185776)
addappid(29545, 1, "294bbd3fe13cf5879b9e8203dd86d2f6e0be165a2c9ccd312f28d4e31ff26ffa") -- Guild Wars Spanish
setManifestid(29545, "6697105966861456616", 2398566064)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(29540) -- Guild Wars Game of the Year Edition
addappid(29560) -- Guild Wars Factions
addappid(29570) -- Guild Wars Trilogy
addappid(29580) -- Guild Wars Nightfall
addappid(29600) -- Guild Wars Game of the Year
addappid(29610) -- Guild Wars Factions
addappid(29620) -- Guild Wars Trilogy
addappid(29630) -- Guild Wars Nightfall
addappid(29700) -- Guild Wars Eye of the North
addappid(29710) -- Guild Wars Eye of the North (EU)
addappid(4103440) -- Guild Wars Reforged Steam Upgrade
addappid(4103450) -- Guild Wars Eye of the North
addappid(4103460) -- Guild Wars Bonus Mission Pack