-- 3092110's Lua and Manifest Created by Morrenus
-- Dungeons & Kingdoms
-- Created: November 19, 2025 at 13:14:29 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3092110) -- Dungeons & Kingdoms
-- MAIN APP DEPOTS
addappid(3092111, 1, "6f8797dfc8bde4bc30cfa1f4989a56260963e651a55c1017069f618ad48a6ba0") -- Depot 3092111
setManifestid(3092111, "8872941379644665128", 12599680923)