-- 3092260's Lua and Manifest Created by Morrenus
-- Sit-Back Attack
-- Created: November 30, 2025 at 10:15:30 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3092260) -- Sit-Back Attack
-- MAIN APP DEPOTS
addappid(3092261, 1, "9e9b17c2532f2611a8665d2f010b7adafb4cb3701771234e1ec252740369b5e9") -- Depot 3092261
setManifestid(3092261, "1355864736663523376", 1078232475)