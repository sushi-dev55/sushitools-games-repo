-- 2393920's Lua and Manifest Created by Morrenus
-- Angeline Era
-- Created: December 09, 2025 at 15:25:32 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(2393920) -- Angeline Era
-- MAIN APP DEPOTS
addappid(2393921, 1, "34583eee1bcbc44ac159342aab7a3df30b818c138e78634c7fea3fbe5c1a7cf0") -- Depot 2393921
setManifestid(2393921, "9022766919530156974", 2306516249)
addappid(2393922, 1, "002f3413433a7b45471a4988100b06fd8b7db3be5e2e30620049f768e2675442") -- Depot 2393922
setManifestid(2393922, "5496020161939866392", 2319384685)
-- DLCS WITH DEDICATED DEPOTS
-- Angeline Era Supporter Pack (AppID: 4166460)
addappid(4166460)
addappid(4166460, 1, "5fc0d189c88c46e462e047e3a4dd807e3243e949acceae531ce7d775172104e2") -- Angeline Era Supporter Pack - Depot 4166460
setManifestid(4166460, "8153771406909058281", 39437070)