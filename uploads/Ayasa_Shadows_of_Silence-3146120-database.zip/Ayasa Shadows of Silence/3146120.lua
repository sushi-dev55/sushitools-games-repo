-- 3146120's Lua and Manifest Created by Morrenus
-- Ayasa: Shadows of Silence
-- Created: November 30, 2025 at 10:10:19 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 5
-- Total DLCs: 0 (1 excluded)
-- Shared Depots: 4

-- MAIN APPLICATION
addappid(3146120) -- Ayasa: Shadows of Silence
-- MAIN APP DEPOTS
addappid(3146121, 1, "5e65e87e83911c82716ec99d5628eade8725cf0de1e2cfe14c4806eb16bf706c") -- Depot 3146121
setManifestid(3146121, "6025274967254042483", 15787833087)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- .NET 4.8 Redist (Shared from App 228980)
setManifestid(229007, "4477590687906973371", 117381405)
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(4091520) -- Ayasa: Shadows of Silence – Digital Artbook (unreleased)