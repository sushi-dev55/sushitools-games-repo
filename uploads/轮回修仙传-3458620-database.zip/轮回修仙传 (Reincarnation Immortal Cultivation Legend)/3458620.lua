-- 3458620's Lua and Manifest Created by Morrenus
-- 轮回修仙传
-- Created: December 09, 2025 at 14:33:10 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3458620, 1, "42ef43def56f26c4d61e0b93e938d45b448a1eb5b155cf95a318d5b04794f373") -- 轮回修仙传
-- MAIN APP DEPOTS
addappid(3458621, 1, "4800e6ba97672ca096369195a3698885d05c5f1bc7c6bde52bda292e1739a783") -- Depot 3458621
setManifestid(3458621, "7888476138572404872", 549807595)