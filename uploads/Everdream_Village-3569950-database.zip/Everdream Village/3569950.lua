-- 3569950's Lua and Manifest Created by Morrenus
-- Everdream Village
-- Created: December 12, 2025 at 18:07:39 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3569950) -- Everdream Village
-- MAIN APP DEPOTS
addappid(3569951, 1, "63fb30c192a460a30454dc257877d5e9818be2c3c6604f55821d74b20ea2d0b4") -- Depot 3569951
setManifestid(3569951, "2881717581614399095", 5661735471)