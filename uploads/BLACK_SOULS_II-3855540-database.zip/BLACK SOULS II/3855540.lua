-- 3855540's Lua and Manifest Created by Morrenus
-- BLACK SOULS II
-- Created: December 01, 2025 at 08:44:46 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3855540) -- BLACK SOULS II
-- MAIN APP DEPOTS
addappid(3855543, 1, "e154687275024a8bbf82b6f179921c298874dfa77b79ef66f3e607b370d1a3ce") -- Depot 3855543
setManifestid(3855543, "1782245658833380789", 1353712716)