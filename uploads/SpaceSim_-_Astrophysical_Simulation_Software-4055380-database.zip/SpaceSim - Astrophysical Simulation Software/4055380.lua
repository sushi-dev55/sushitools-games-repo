-- 4055380's Lua and Manifest Created by Morrenus
-- SpaceSim
-- Created: December 18, 2025 at 11:28:36 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(4055380, 1, "1413874e8afb00c37463990868f9cfb47ea876020a63d11fd02de3f8d941e939") -- SpaceSim
-- MAIN APP DEPOTS
addappid(4055381, 1, "c9d66eb676ab6239bc5e1dd5c5f5d57ecd66c7f72930b3958dffde1e9a6abc4a") -- Depot 4055381
setManifestid(4055381, "83068506003244508", 137091792)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)