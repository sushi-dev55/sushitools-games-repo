-- 3843520's Lua and Manifest Created by Morrenus
-- The Temple of Elemental Evil
-- Created: December 11, 2025 at 10:45:55 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3843520) -- The Temple of Elemental Evil
-- MAIN APP DEPOTS
addappid(3843521, 1, "e71ac7287be800d6f5e5c9f57deaf9f434c02191bab0094e6369cf2e709a5f72") -- Depot 3843521
setManifestid(3843521, "3024911635560070612", 2358838621)