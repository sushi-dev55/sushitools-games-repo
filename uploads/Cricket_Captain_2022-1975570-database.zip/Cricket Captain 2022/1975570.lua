-- 1975570's Lua and Manifest Created by Morrenus
-- Cricket Captain 2022
-- Created: December 11, 2025 at 12:49:20 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1975570) -- Cricket Captain 2022
-- MAIN APP DEPOTS
addappid(1975571, 1, "75b67e32d49c33c8dc8015a0c632824ccde4e8063c25a00f41445e2f1624c8d6") -- Depot 1975571
setManifestid(1975571, "6488547036358235512", 271700229)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)