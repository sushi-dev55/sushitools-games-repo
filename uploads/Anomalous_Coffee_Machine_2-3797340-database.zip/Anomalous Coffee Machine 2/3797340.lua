-- 3797340's Lua and Manifest Created by Morrenus
-- Anomalous Coffee Machine 2
-- Created: December 13, 2025 at 08:47:05 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(3797340) -- Anomalous Coffee Machine 2
-- MAIN APP DEPOTS
addappid(3797341, 1, "817798feb3ccb1755b4d2175aadb9d3216fa1b79ab93b78223a310ad2e7fa129") -- Depot 3797341
setManifestid(3797341, "1611986137511903080", 1643068784)
-- DLCS WITH DEDICATED DEPOTS
-- Anomalous Coffee Machine 2 - NSFW (AppID: 3875100)
addappid(3875100)
addappid(3875100, 1, "9d0f323d7f3c0b74ea236aa04550242e23dc01af62ceee3c6bfacd5c5916aa51") -- Anomalous Coffee Machine 2 - NSFW - Depot 3875100
setManifestid(3875100, "1085655816325080530", 498860912)