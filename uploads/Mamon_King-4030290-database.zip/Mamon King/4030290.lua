-- 4030290's Lua and Manifest Created by Morrenus
-- Mamon KIng
-- Created: December 11, 2025 at 10:48:52 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4030290) -- Mamon KIng
-- MAIN APP DEPOTS
addappid(4030291, 1, "7ebefd2fc0ad43fc4b54f048ee65284aad7f97fe6b7fb7f3b3871a3a941938cf") -- Depot 4030291
setManifestid(4030291, "484715236284567900", 1711258530)