-- 817720's Lua and Manifest Created by Morrenus
-- Cricket Captain 2018
-- Created: October 02, 2025 at 02:43:51 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(817720) -- Cricket Captain 2018
-- MAIN APP DEPOTS
addappid(817721, 1, "cd650f7f8613bf8570f3437e5af7b756c80190b18d2b594b62bd7dc621619505") -- Cricket Captain 2018 Content
setManifestid(817721, "687034176294943652", 254850731)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)