-- 1414910's Lua and Manifest Created by Morrenus
-- The Shimmering Horizon and Cursed Blacksmith
-- Created: December 01, 2025 at 07:20:08 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1414910) -- The Shimmering Horizon and Cursed Blacksmith
-- MAIN APP DEPOTS
addappid(1414911, 1, "d6217f7868c7d33554670ef8d0b008e1fed943fff12d5026ed5e3ffa4c8dd9e6") -- Depot 1414911
setManifestid(1414911, "8214564544614547410", 2716615771)