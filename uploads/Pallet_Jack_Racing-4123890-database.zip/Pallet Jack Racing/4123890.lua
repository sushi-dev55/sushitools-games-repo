-- 4123890's Lua and Manifest Created by Morrenus
-- Pallet Jack Racing
-- Created: December 17, 2025 at 08:42:28 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4123890) -- Pallet Jack Racing
-- MAIN APP DEPOTS
addappid(4123891, 1, "57f8ade11e3da0d0ea5de908788154b8e3414213cd52a4235b98676315385370") -- Depot 4123891
setManifestid(4123891, "8593689612700531255", 3814979444)