-- 2467850's Lua and Manifest Created by Morrenus
-- Wild Growth
-- Created: December 04, 2025 at 05:01:31 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2467850) -- Wild Growth
-- MAIN APP DEPOTS
addappid(2467851, 1, "fb5cfd481283c6f65fd0af95b95ae38678015a49d3f3706c79f07b492d8b5695") -- Depot 2467851
setManifestid(2467851, "1913894202191471978", 145391400)