-- 606160's Lua and Manifest Created by Morrenus
-- ROUTINE
-- Created: December 04, 2025 at 11:15:19 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(606160) -- ROUTINE
-- MAIN APP DEPOTS
addappid(606161, 1, "f1cd8fe75a865cf2333d06c14f644b5ef8dd9fc4425aac2a35ae7a75eb4da0b1") -- Depot 606161
setManifestid(606161, "3354729828789611007", 10723497669)