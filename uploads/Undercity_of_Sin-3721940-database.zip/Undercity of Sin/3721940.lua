-- 3721940's Lua and Manifest Created by Morrenus
-- Undercity of Sin
-- Created: December 07, 2025 at 04:33:57 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3721940) -- Undercity of Sin
-- MAIN APP DEPOTS
addappid(3721941, 1, "d24ee73f49887dbe3eb8cbc0b1187086b55fd587df7f94e6d6af7009cc42cdff") -- Depot 3721941
setManifestid(3721941, "3472876156740552024", 1377222556)
addappid(3721942, 1, "195e9731ba449cbd120b05484d5f95fcf9af2da292dac1c3b5561b4ba6628db7") -- Depot 3721942
setManifestid(3721942, "3208832470010965704", 25498234)
addappid(3721943, 1, "7a42961f428a68d5bb3868c63c8b237d7a41fda46a1beff6e9ed6be16fadc187") -- Depot 3721943
setManifestid(3721943, "2070063400027175285", 11904643)