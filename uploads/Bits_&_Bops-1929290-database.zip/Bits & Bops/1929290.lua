-- 1929290's Lua and Manifest Created by Morrenus
-- Bits & Bops
-- Created: December 10, 2025 at 06:55:30 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1929290) -- Bits & Bops
-- MAIN APP DEPOTS
addappid(1929291, 1, "91ae978375944c164d52183a42b80bcba7be0c3e9862e50167fe9820c43ac287") -- Depot 1929291
setManifestid(1929291, "2110749406372938251", 2913626334)