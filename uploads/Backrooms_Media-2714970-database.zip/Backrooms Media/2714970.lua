-- 2714970's Lua and Manifest Created by Morrenus
-- Backrooms Media
-- Created: December 17, 2025 at 03:30:05 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(2714970, 1, "6d16544a747d217e97e23743b53278101aca1497163ab5f633ded3af343112a8") -- Backrooms Media
-- MAIN APP DEPOTS
addappid(2714971, 1, "ab4bc4223396ff5d6b91856b16a2f239cf1ca363f100362049154f2b54d3e3a7") -- Depot 2714971
setManifestid(2714971, "2923362800947727160", 11004781118)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- .NET 4.8 Redist (Shared from App 228980)
setManifestid(229007, "4477590687906973371", 117381405)