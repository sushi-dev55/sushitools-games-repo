-- 462700's Lua and Manifest Created by Morrenus
-- Cricket Captain 2016
-- Created: October 02, 2025 at 01:43:04 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(462700) -- Cricket Captain 2016
-- MAIN APP DEPOTS
addappid(462701, 1, "602df28a75949b119ceee41718e8f6e2fad5712c051c8e1e11e98da27c81eac3") -- Cricket Captain 2016 Windows
setManifestid(462701, "114604318794589250", 191364820)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)