-- 2825880's Lua and Manifest Created by Morrenus
-- Death Howl
-- Created: December 09, 2025 at 14:32:51 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(2825880) -- Death Howl
-- MAIN APP DEPOTS
addappid(2825881, 1, "0c90c69e81a5bd9620fc855eb40f4711537009e37f3dea0788780b6c18df1994") -- Depot 2825881
setManifestid(2825881, "6621731469568157493", 3635513829)
-- DLCS WITH DEDICATED DEPOTS
-- Death Howl Artbook  Relics (AppID: 4126800)
addappid(4126800)
addappid(4126800, 1, "10555f8da88716f66e7ecc0becc3bf9a1eccfd3de0d059645ed9bb89a1110007") -- Death Howl Artbook  Relics - Depot 4126800
setManifestid(4126800, "8034861370648510376", 210451286)