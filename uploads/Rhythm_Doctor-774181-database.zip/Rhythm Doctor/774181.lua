-- 774181's Lua and Manifest Created by Morrenus
-- Rhythm Doctor
-- Created: December 08, 2025 at 13:07:31 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 5
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(774181, 1, "54c730f0832db85585d3feedbc7af7061f7ad1c6fe0b1123dce46ec60e011a64") -- Rhythm Doctor
-- MAIN APP DEPOTS
addappid(774182, 1, "76d37d204d148b56554e8f8de5fba461e96eb4206c11c67aaf4fce8327ddd0a9") -- Rhythm Doctor Windows
setManifestid(774182, "7565264792876159819", 1121067324)
addappid(774185, 1, "106fec9539cb2a9532e537df1fda91b4297a1482dfc2799a4b79aa8df59a55d5") -- Depot 774185
setManifestid(774185, "3272956638175184066", 1134019684)
addappid(774183, 1, "51118da8096080b0800e51f785e7b8812e81e340ad4f3e6caed07a39ff96ecab") -- Rhythm Doctor Mac
setManifestid(774183, "15009276535328975", 1156889811)
addappid(774184, 1, "3ae0a202ba2e80ef7386acf3a1f9014a1bf2bec36d70f66349afb9495e030006") -- Depot 774184
setManifestid(774184, "817773793064557305", 1128582418)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)