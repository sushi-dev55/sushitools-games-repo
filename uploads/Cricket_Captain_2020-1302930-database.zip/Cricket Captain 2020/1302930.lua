-- 1302930's Lua and Manifest Created by Morrenus
-- Cricket Captain 2020
-- Created: October 02, 2025 at 03:49:47 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1302930) -- Cricket Captain 2020
-- MAIN APP DEPOTS
addappid(1302931, 1, "b91ed559a9fc14a2667289f89e389df47f2ed73c0124b4225b8c42364b246184") -- Cricket Captain 2020 Content
setManifestid(1302931, "3419293612384760391", 258226566)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)