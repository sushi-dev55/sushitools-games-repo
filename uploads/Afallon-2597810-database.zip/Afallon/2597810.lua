-- 2597810's Lua and Manifest Created by Morrenus
-- Afallon
-- Created: December 04, 2025 at 11:13:29 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2597810) -- Afallon
-- MAIN APP DEPOTS
addappid(2597811, 1, "084e7d51d514f3a5b9d28a0fb64f6e7e0957abd73ec2a03691f3b331a14687ff") -- Depot 2597811
setManifestid(2597811, "365543530993961204", 20020032457)