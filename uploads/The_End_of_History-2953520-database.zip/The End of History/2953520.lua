-- 2953520's Lua and Manifest Created by Morrenus
-- The End of History
-- Created: December 10, 2025 at 16:57:13 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2953520) -- The End of History
-- MAIN APP DEPOTS
addappid(2953521, 1, "f5824a41e775cbc1cc788b8f5c4654a7518787b38d887bb37285e5864087b2c3") -- Depot 2953521
setManifestid(2953521, "4064848761213236287", 2808222734)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)