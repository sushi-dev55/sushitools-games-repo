-- 2350790's Lua and Manifest Created by Morrenus
-- Moonlighter 2: The Endless Vault
-- Created: November 20, 2025 at 10:43:01 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2350790) -- Moonlighter 2: The Endless Vault
-- MAIN APP DEPOTS
addappid(2350792, 1, "794eca19bb31db7e79bbc69f303feb210c8e3efca02f89ff7d38d9e0fed8705f") -- Depot 2350792
setManifestid(2350792, "7896654813095822608", 4898734429)