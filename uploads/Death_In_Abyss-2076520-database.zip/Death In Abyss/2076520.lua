-- 2076520's Lua and Manifest Created by Morrenus
-- Death In Abyss
-- Created: December 05, 2025 at 10:43:10 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2076520) -- Death In Abyss
-- MAIN APP DEPOTS
addappid(2076521, 1, "fea02babfed3d7126014c8da3773dff000d33d57d3d49d4b66f298727227c0e0") -- Depot 2076521
setManifestid(2076521, "1283981703760098602", 307814716)