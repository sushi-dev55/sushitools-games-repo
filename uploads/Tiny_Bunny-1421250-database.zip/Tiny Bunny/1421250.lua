-- 1421250's Lua and Manifest Created by Morrenus
-- Tiny Bunny
-- Created: December 05, 2025 at 12:24:14 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(1421250) -- Tiny Bunny
-- MAIN APP DEPOTS
addappid(1421251, 1, "26c7441369eb15b5a36a102139161693464b46afa6f77cc7744ea95f920ece2c") -- TINY BUNNY Content
setManifestid(1421251, "283667402466455273", 7123105768)
addappid(1421252, 1, "0179a2642033cb165f6992abded21663174ebdb683dade998bef17cf1aa13af0") -- Depot 1421252
setManifestid(1421252, "5033706032853790440", 7015242589)
-- DLCS WITH DEDICATED DEPOTS
-- Tiny bunny - Manga Vol. 1 (AppID: 3787220)
addappid(3787220)
addappid(3787220, 1, "c9edd435068cdbc2aac07cfa826cda1b8db0e3a820b6de7c23832f2f0bbcb076") -- Tiny bunny - Manga Vol. 1 - Depot 3787220
setManifestid(3787220, "7795759918091215640", 336637871)