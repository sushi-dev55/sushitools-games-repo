-- 3713480's Lua and Manifest Created by Morrenus
-- How to create a witch
-- Created: December 07, 2025 at 07:03:18 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3713480) -- How to create a witch
-- MAIN APP DEPOTS
addappid(3713482, 1, "6ee75e45e892c6b1f1100a9c5dee5c84f401fe1c1eb0fe591d97282ebc258f28") -- Depot 3713482
setManifestid(3713482, "4993109586474218383", 613615226)