-- 4033610's Lua and Manifest Created by Morrenus
-- Ecopunk
-- Created: December 04, 2025 at 05:54:08 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4033610) -- Ecopunk
-- MAIN APP DEPOTS
addappid(4033611, 1, "82f3094341aeb3a70b34305090a7cd5b99b4346e14348fa08a638ed4fd8c73eb") -- Depot 4033611
setManifestid(4033611, "3990971010499893400", 1217757994)