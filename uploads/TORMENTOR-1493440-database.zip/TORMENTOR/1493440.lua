-- 1493440's Lua and Manifest Created by Morrenus
-- TORMENTOR
-- Created: December 11, 2025 at 23:15:48 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 0 (2 excluded)
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1493440) -- TORMENTOR
-- MAIN APP DEPOTS
addappid(1493441, 1, "885b50a2965195447f630d3b629ac75440f44061f773b5685d235475f31c35d8") -- Depot 1493441
setManifestid(1493441, "5698577770992112900", 14575413006)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Tormentor - Comic Book (AppID: 4171980) - missing depot keys
-- addappid(4171980)
-- Tormentor - Supporter (AppID: 4171990) - missing depot keys
-- addappid(4171990)