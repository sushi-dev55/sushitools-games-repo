-- 3027910's Lua and Manifest Created by Morrenus
-- One Last Raid
-- Created: December 10, 2025 at 09:43:14 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3027910) -- One Last Raid
-- MAIN APP DEPOTS
addappid(3027911, 1, "0b68b9a917a76809392bf6dabb76598938306d3e6c23e78f5ddf215893c40257") -- Depot 3027911
setManifestid(3027911, "6823649582702504451", 702123057)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)