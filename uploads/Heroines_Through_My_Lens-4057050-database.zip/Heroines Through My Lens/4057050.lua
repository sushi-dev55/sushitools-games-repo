-- 4057050's Lua and Manifest Created by Morrenus
-- Heroines Through My Lens
-- Created: December 16, 2025 at 02:43:24 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4057050) -- Heroines Through My Lens
-- MAIN APP DEPOTS
addappid(4057051, 1, "08db9368d6ef975eb6ff3f8b211c46f28d9dde5dc845f795c8d90efddd994976") -- Depot 4057051
setManifestid(4057051, "6386833759289790148", 33013600960)