-- 1604060's Lua and Manifest Created by Morrenus
-- Cricket Captain 2021
-- Created: October 02, 2025 at 04:23:29 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1604060) -- Cricket Captain 2021
-- MAIN APP DEPOTS
addappid(1604061, 1, "3725f46207757bdc4762ebc76d8690d7bbad807843b9e3fa4ceb2827e4d94471") -- Cricket Captain 2021 Content
setManifestid(1604061, "8700150290591448052", 261730414)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)