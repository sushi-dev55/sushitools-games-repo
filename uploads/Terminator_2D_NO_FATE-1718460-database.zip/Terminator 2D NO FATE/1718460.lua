-- 1718460's Lua and Manifest Created by Morrenus
-- Terminator 2D: NO FATE
-- Created: December 12, 2025 at 07:03:31 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1718460) -- Terminator 2D: NO FATE
-- MAIN APP DEPOTS
addappid(1718464, 1, "00899aaef937ce8103916c7f16e99a4a3efb37c015467e8b4419bd7d6f5129eb") -- Depot 1718464
setManifestid(1718464, "6990083820458598126", 645801992)