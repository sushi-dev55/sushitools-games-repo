-- 3629780's Lua and Manifest Created by Morrenus
-- Tingus Goose
-- Created: December 04, 2025 at 05:44:06 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3629780) -- Tingus Goose
-- MAIN APP DEPOTS
addappid(3629782, 1, "8f03aa732cc4b1198ea2125fb52c3e4bbab21ffd684df6486f10bdc5ebe31292") -- Depot 3629782
setManifestid(3629782, "7279484976521902456", 618613904)
addappid(3629783, 1, "45d1b491c7798639b87ba46ff949b7c964f679a9df55a998f83c8316d0251cfb") -- Depot 3629783
setManifestid(3629783, "9082834778428353135", 641181881)