-- 3846120's Lua and Manifest Created by Morrenus
-- MineMogul
-- Created: December 07, 2025 at 05:53:10 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3846120) -- MineMogul
-- MAIN APP DEPOTS
addappid(3846121, 1, "762f14d01797d4a5166b7f103193c6aadf093edc99b8a83004e2c18c1de4a281") -- Depot 3846121
setManifestid(3846121, "6651958195594117145", 998697096)