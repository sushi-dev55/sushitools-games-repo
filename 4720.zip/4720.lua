-- Made by @f1uxin, If you would like to check out my discord server here's a link : https://discord.gg/NmmpgnAgen
-- In my server we help with mani & lua files, fixes, and honestly just anything about piracy,
-- You can dm me "f1uxin" on discord if you have any questions or anything I'm normally pretty active, and enjoy!
-- If you want to redistribute/share these files please add and dm "f1uxin" on discord to talk more, me and my friend pay for these games with our own money, we do get games cheaper but its still money that we have and are spending so it sucks when people steal/don't credit me at all.

-- P.S On some socials you may find another person with a close name to me, its "f1uxin sells" or "f1uxins shop" any accounts like that are not mine, i do not sell anything, everything I show is free.

-- P.S. #2. This one is important, you see the "setManifestid" lines below right? If you want your game to "auto update" put "--" without the "" Infront of each "setManifestid" or you can completely remove those lines but that is not recommended, then just save this file, and add it however you add mani & lua files. Example "--setManifestid"

-- Guns.lol link (guns.lol is like linktree, its just my socials) : https://guns.lol/f1uxin


-- MAIN APPLICATION
addappid(4720)
addappid(4721,0,"c2083cb1aece8efb25415edade9f2c27feaca519bd74b53d3066baed41457557")
setManifestid(4721,"8395113994574511098")
addappid(4722,0,"bb2648007705bfa3657375de8c3e20806455e96447d871dadb6deb56c650c9bb")
setManifestid(4722,"7225834229027005444")
addappid(4723,0,"0310ee1f7f0a7eaa7d930a9c53b268b2f5b572457454cd135f33bdf943807015")
setManifestid(4723,"4147799527871569818")
addappid(4724,0,"93273e569372b39b967019e0daf236e215a3de515d8c109f3f5a194a44c0f5ba")
setManifestid(4724,"8581301575444572156")
addappid(4725,0,"ec953b8566b44b31ce70824c8c30f6eadd36d9c6bb2a618dbc7098077715a6a3")
setManifestid(4725,"638573850646940651")
addappid(4726,0,"c93ce9f63d6b4b63e789a8e7f2259f9144d2875ccfbe16eeeed4edafdc055b49")
setManifestid(4726,"4069817558832441280")