-- Made by F1uxin, Discord ID:965053505901588521 | Discord Server (TGP | The Galaxy of Pirates): https://discord.gg/VfCxRsFyFe

-- If you're interested in distributing these files please dm me on discord (UserID:965053505901588521) 
-- (I don't care if you send them to a friend or to help someone, just if you add them in your bot or have them widely available then i would like to know.)

-- Socials: https://guns.lol/f1uxin

-- If you have any questions feel free to dm on discord (UserID:965053505901588521)


-- Main stuff to actually add the game, DLCs, & depots.
addappid(2483190, 1, "bca2f0f9973d929c2c6bae884058b8bf7934e9ecc8ff34d584450dfbb3215040") -- Forza Horizon 6
addappid(2483191, 1, "f2a09f0a31b4df681ec0d2d572f368dfa4cd6c37ae67ebdfd591cfbe1334fcd9") -- Depot 2483191
setManifestid(2483191, "8528223014919165744", 167126368613)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(4439260) -- Forza Horizon 6 Welcome Pack
addappid(4439270) -- Forza Horizon 6 Premium VIP
addappid(4439280) -- Forza Horizon 6 Time Attack Car Pack
addappid(4439300) -- Forza Horizon 6 Ferrari J50
addappid(4439750) -- Forza Horizon 6 Treasure Map
addappid(4439790) -- Forza Horizon 6 Car Pass
addappid(4439800) -- Forza Horizon 6 1990 Nissan 12 Skyline GT-R (BNR32 Gr.A) JTC
addappid(4439810) -- Forza Horizon 6 2024 Koenigsegg Gemera
addappid(4439820) -- Forza Horizon 6 1972 Datsun 269 Attacking the Clock Racing 240Z All Carbon Hill Climb Beast
addappid(4439830) -- Forza Horizon 6 2008 Honda Civic Type R (FD2)
addappid(4439840) -- Forza Horizon 6 2023 Audi R8 Coup V10 GT RWD
addappid(4439890) -- Forza Horizon 6 1974 Mazda 123 Mad Mike 808 Wagon FURSTY
addappid(4440380) -- Forza Horizon 6 VIP Membership
addappid(4444140) -- Forza Horizon 6 TBDS2
addappid(4444150) -- Forza Horizon 6 1962 Peel P50 Trolli Edition
addappid(4520350) -- Forza Horizon 6 Expansions Bundle
addappid(4520360) -- Forza Horizon 6 Premium Upgrade Bundle
addappid(4562050) -- Forza Horizon 6 Crunchyroll Voucher
addappid(4610350) -- Forza Horizon 6 1998 Nissan Skyline GT-R 40th Anniversary