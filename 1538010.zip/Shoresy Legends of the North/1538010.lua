-- 1538010's Lua and Manifest Created by Morrenus
-- Shoresy: Legends of the North
-- Created: November 28, 2025 at 08:27:57 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1538010) -- Shoresy: Legends of the North
-- MAIN APP DEPOTS
addappid(1538011, 1, "3ee3e5a534423b03982344d86e7d76bef1fbc476a5369c7d427b6e360d173f10") -- Depot 1538011
setManifestid(1538011, "5967742937950847197", 8426035450)