-- Made by @f1uxin, If you would like to check out my discord server here's a link : https://discord.gg/NmmpgnAgen
-- In my server we help with mani & lua files, fixes, and honestly just anything about piracy,
-- You can dm me "f1uxin" on discord if you have any questions or anything I'm normally pretty active, and enjoy!
-- If you want to redistribute/share these files please add and dm "f1uxin" on discord to talk more, me and my friend pay for these games with our own money, we do get games cheaper but its still money that we have and are spending so it sucks when people steal/don't credit me at all.

-- P.S On some socials you may find another person with a close name to me, its "f1uxin sells" or "f1uxins shop" any accounts like that are not mine, i do not sell anything, everything I show is free.

-- P.S. #2. This one is important, you see the "setManifestid" lines below right? If you want your game to "auto update" put "--" without the "" Infront of each "setManifestid" or you can completely remove those lines but that is not recommended, then just save this file, and add it however you add mani & lua files. Example "--setManifestid"

-- Guns.lol link (guns.lol is like linktree, its just my socials) : https://guns.lol/f1uxin


-- MAIN APPLICATION
addappid(1778820) -- TEKKEN 8
addappid(1778821, 1, "c7c87be587ce9a828a290d82a8650ff9edd77f53919f2f8d2f686f1e586417b7") -- Depot 1778821
setManifestid(1778821, "5266519841901964539", 130070152418)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(3025000)
addappid(3025000, 1, "afe85b92428daa47e2254a44004a7f97b0defce56555bcca59a44a94e357f373") -- TEKKEN 8 - GENMAJI TEMPLE - Depot 3025000
setManifestid(3025000, "7282372065457185729", 34884128)
addappid(3145890)
addappid(3145890, 1, "8587b0c4c63e914df99aedf5179181d680a74c88324d4e86a80cb08baff28efb") -- TEKKEN 8 - PHOENIX GATE (FINAL FANTASY series) - Depot 3145890
setManifestid(3145890, "8461657819190922589", 39846240)
addappid(3564550)
addappid(3564550, 1, "4839f0f96b42c57b6e15373696ba97c30db5aff2511924e376a443f594af0ab4") -- TEKKEN 8 - PAC-PIXELS - Depot 3564550
setManifestid(3564550, "3006045251628593482", 35651936)
addappid(2512940) -- TEKKEN 8 - Avatar Costume Paul Phoenix Set
addappid(2512950) -- TEKKEN 8 - Character Costume Gold Suit Pack
addappid(2512960) -- TEKKEN 8 - Avatar Costume Classic TEKKEN T-Shirt Set
addappid(2512970) -- TEKKEN 8 - Avatar Skin Kazuya Mishima
addappid(2512980) -- TEKKEN 8 - Avatar Skin Jun Kazama
addappid(2512990) -- TEKKEN 8 - Avatar Skin Jin Kazama
addappid(2513000) -- TEKKEN 8 - Avatar Skin Kinjin
addappid(2518100) -- TEKKEN 8 - Avatar Skin Tetsujin
addappid(2518110) -- TEKKEN 8 - Avatar Skin Mokujin
addappid(2732280) -- TEKKEN 8 - Eddy Gordo
addappid(2741980) -- TEKKEN 8 - Deluxe Edition Upgrade Pack
addappid(2741990) -- TEKKEN 8 - Ultimate Pack
addappid(2891170) -- TEKKEN 8 - Lidia Sobieska
addappid(3024980) -- TEKKEN 8 - Heihachi Mishima
addappid(3145880) -- TEKKEN 8 - Clive Rosfield (FINAL FANTASY series)
addappid(3303020) -- TEKKEN 8 - Collaboration Set Clive Rosfield  PHOENIX GATE (FINAL FANTASY series)
addappid(3417000) -- TEKKEN 8 - Anna Williams
addappid(3417230) -- TEKKEN 8 - Season 1 Character Pass
addappid(3417240) -- TEKKEN 8 - Season 1 Character  Stage Pass
addappid(3417250) -- TEKKEN 8 - Season 2 Character Pass
addappid(3417270) -- TEKKEN 8 - Season 2 Character  Stage Pass
addappid(3417280) -- TEKKEN 8 - Customization Item Pack
addappid(3564540) -- TEKKEN 8 - Fahkumram
addappid(3775990) -- TEKKEN 8 - Armor King