-- Made by F1uxin (UserID:965053505901588521), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/NmmpgnAgen)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:965053505901588521)
-- And if you have any questions feel free to dm on discord (UserID:965053505901588521)

-- Socials: https://guns.lol/f1uxin

-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)

-- Main stuff to add your game.
addappid(3681010, 1, "accea0016c6c5df7d031a08df7a460e90673b8da5c7cfb57432bb7e962893897") 
addappid(3681011, 1, "1c16eb875f0bd40521cc0ddb2ff4eb5772f0b1976252122abc5f9a09ddaaf995") 
setManifestid(3681011, "8621284847782794237", 121881045115)
addappid(3681013, 1, "b97a4048032dc27c3cf1c6887e6069b0f0d51da2c352c671278b00eb4423de35") 
setManifestid(3681013, "3120992644566989993", 319584)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") 
setManifestid(228988, "6645201662696499616", 29212173)
addappid(4003880) 
addappid(4003890) 
addappid(4003900) 
addappid(4003910) 
addappid(4003920) 
addappid(4003930) 
addappid(4003940) 
addappid(4232000) 
addappid(4232020) 
addappid(4232030) 