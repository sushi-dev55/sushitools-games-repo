-- 3985030's Lua and Manifest Created by Morrenus
-- Air Defender
-- Created: December 04, 2025 at 11:14:45 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3985030) -- Air Defender
-- MAIN APP DEPOTS
addappid(3985031, 1, "b61cb556d1a111c34e0504e8c767d4eeb6bb97043feb5faad9c06a7bb1b57518") -- Depot 3985031
setManifestid(3985031, "7195477310476761710", 1205518338)