-- 3352240's Lua and Manifest Created by Morrenus
-- Raiders of Blackveil
-- Created: December 17, 2025 at 08:16:10 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3352240) -- Raiders of Blackveil
-- MAIN APP DEPOTS
addappid(3352241, 1, "6a82f2c4778c4822edb4e249b8d269bcc004d047eb7dc974c21f99202939ab5c") -- Depot 3352241
setManifestid(3352241, "851455807916910320", 8270597061)