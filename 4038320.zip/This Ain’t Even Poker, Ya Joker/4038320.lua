-- 4038320's Lua and Manifest Created by Morrenus
-- This Ain’t Even Poker, Ya Joker
-- Created: December 11, 2025 at 19:22:42 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4038320) -- This Ain’t Even Poker, Ya Joker
-- MAIN APP DEPOTS
addappid(4038321, 1, "b5d87fb249e7176e69ca241653736083a4a0541b13a81aef13b5231b82131364") -- Depot 4038321
setManifestid(4038321, "6351861712587063305", 462764297)