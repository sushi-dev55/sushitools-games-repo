-- Made by @f1uxin, If you would like to check out my discord server here's a link : https://discord.gg/NmmpgnAgen
-- In my server we help with mani & lua files, fixes, and honestly just anything about piracy,
-- You can dm me "f1uxin" on discord if you have any questions or anything I'm normally pretty active, and enjoy!
-- If you want to redistribute/share these files please add and dm "f1uxin" on discord to talk more, me and my friend pay for these games with our own money, we do get games cheaper but its still money that we have and are spending so it sucks when people steal/don't credit me at all.

-- P.S On some socials you may find another person with a close name to me, its "f1uxin sells" or "f1uxins shop" any accounts like that are not mine, i do not sell anything, everything I show is free.

-- P.S. #2. This one is important, you see the "setManifestid" lines below right? If you want your game to "auto update" put "--" without the "" Infront of each "setManifestid" or you can completely remove those lines but that is not recommended, then just save this file, and add it however you add mani & lua files. Example "--setManifestid"

-- Guns.lol link (guns.lol is like linktree, its just my socials) : https://guns.lol/f1uxin


-- MAIN APPLICATION
addappid(2651280)
addappid(3172650)
addappid(3172660)
addappid(2651281,0,"9874571b52ba0c01cbdfd32c5d81920d1093f42fbcf76d02a1e4589746a3b497")
setManifestid(2651281,"8012952727343622296")
addappid(2651282,0,"ab459f096f7d0fd0720dd711f19036f532f2678314af4155ed197882c260b539")
setManifestid(2651282,"3767121848454326847")
addappid(2651283,0,"e342794b2586f10e0a3273560bda0fb524b448519ff20b6ec938d03e5b949104")
setManifestid(2651283,"3140959264389958880")
addappid(2651284,0,"11af403d500753e060bd806ed360e9bf5031e0e846a9ba50a876f68fcb61c641")
setManifestid(2651284,"846324441252010395")
addappid(2651285,0,"14ad0c77584264070ad5cbedf200f8747660475645d0527c93425de942df6d1b")
setManifestid(2651285,"4328447403863919771")
addappid(2651286,0,"f33f54c66e41670774919e410838c06145826bfabe00def0753399b0ffe58b4a")
setManifestid(2651286,"3948777963018938239")
addappid(2651287,0,"4ab098c2d61d6bc168fb4067cfc2377f9865275310e1e86c960a12de83a39ee9")
setManifestid(2651287,"2606619191523762582")
addappid(2651288,0,"0a0e8a531cc2d2483435dcc5d3d0969712b646c0718c39991b0e64d2e0b9a1fd")
setManifestid(2651288,"1855407133619078595")
addappid(2651289,0,"14052de118633012aec3fe99b7a692bee3da4c8604d126f7b057f416d327c488")
setManifestid(2651289,"3489818852177941630")
addappid(2666312,0,"ecb0cd78998a33161c79c8cc7130a578af813aa46c6d8c54fe7227167ebba919")
setManifestid(2666312,"9017518683281573318")
addappid(2666313,0,"4cbc4b49aefb9e6a43312b89474b674d8147e3294baa418b46b3b6c34a9d6850")
setManifestid(2666313,"3294919126505310189")
addappid(2666314,0,"58b3013867940ee2998334b9c0412ab2ccc4310a529c231bb74cec034dd2c645")
setManifestid(2666314,"7392338523748818045")
addappid(2666315,0,"319c6ed61f3fd2d4571eed5b5132ba16c780d70712db62109e2aa814a912e803")
setManifestid(2666315,"2989068998349913273")
addappid(2666316,0,"49480a4027a30684386dc0f2b32494b7424bbbe67234983c07644a0211ccb61c")
setManifestid(2666316,"8497632270659961146")
addappid(2666311,0,"3bf280f2400be0851c8f7f1872d8c48884df409d8d8e933615ac85b9a972836a")
setManifestid(2666311,"7167820393896288073")