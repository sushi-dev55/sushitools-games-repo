-- 2753970's Lua and Manifest Created by Morrenus
-- MARVEL Cosmic Invasion
-- Created: December 01, 2025 at 14:20:25 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2753970) -- MARVEL Cosmic Invasion
-- MAIN APP DEPOTS
addappid(2753971, 1, "ff109204aa554d768b70d4a127f48f336e2817a37eb4f43ece799db7987c596d") -- Depot 2753971
setManifestid(2753971, "7731191905672200595", 502161002)
addappid(2753972, 1, "c37ee07f99ae25fae9bb80371746aa3ccb5b2d8eb9fc2f9bd590d0908c5e400f") -- Depot 2753972
setManifestid(2753972, "2573447349162892739", 64759492)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- .NET 4.7 Redist (Shared from App 228980)
setManifestid(229006, "1784011429307107530", 83944258)