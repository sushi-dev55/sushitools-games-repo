-- Made by @f1uxin, If you would like to check out my discord server here's a link : https://discord.gg/NmmpgnAgen
-- In my server we help with mani & lua files, fixes, and honestly just anything about piracy,
-- You can dm me "f1uxin" on discord if you have any questions or anything I'm normally pretty active, and enjoy!
-- If you want to redistribute/share these files please add and dm "f1uxin" on discord to talk more, me and my friend pay for these games with our own money, we do get games cheaper but its still money that we have and are spending so it sucks when people steal/don't credit me at all.

-- P.S On some socials you may find another person with a close name to me, its "f1uxin sells" or "f1uxins shop" any accounts like that are not mine, i do not sell anything, everything I show is free.

-- P.S. #2. This one is important, you see the "setManifestid" lines below right? If you want your game to "auto update" put "--" without the "" Infront of each "setManifestid" or you can completely remove those lines but that is not recommended, then just save this file, and add it however you add mani & lua files. Example "--setManifestid"

-- Guns.lol link (guns.lol is like linktree, its just my socials) : https://guns.lol/f1uxin


-- MAIN APPLICATION
addappid(341800)
addappid(341800,0,"1affcd096e6e13525be1a4d54d0365223e983b2dd9e4af35e0e4198de31fae3f")
addappid(341804,0,"39749b7fbb22631d93260af41062aba00d0490e5aeff02e7c9f0258978f8be85")
setManifestid(341804,"3201216360315509764")
addappid(341801,0,"7a3268e19c324c33a765f5d6411b261b4025d30a399dc9cc1e279ec8d64f33c6")
setManifestid(341801,"8711988109837842559")
addappid(341802,0,"e2113a997e3ff5b772be46811bab8ec43ed7e423dc2737fc54626fbe2c2b49ef")
setManifestid(341802,"5369102617851565549")
addappid(341803,0,"8b152cd65ba73c1b340af9e6476ae1e2e9f288dcec76123797c0271bcdf89c5c")
setManifestid(341803,"1012396589549340219")