-- 1817500's Lua and Manifest Created by Morrenus
-- Abandoned Archive
-- Created: December 02, 2025 at 00:26:13 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1817500) -- Abandoned Archive
-- MAIN APP DEPOTS
addappid(1817501, 1, "9adc35fa88e6b7b2e04b7fddb4b1bed229d227d8e4e1fc5ef6c448a9575b9bd8") -- Depot 1817501
setManifestid(1817501, "6722794996861018516", 1420524740)