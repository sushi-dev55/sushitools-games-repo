-- Made by @f1uxin, If you would like to check out my discord server here's a link : https://discord.gg/NmmpgnAgen
-- In my server we help with mani & lua files, fixes, and honestly just anything about piracy,
-- You can dm me "f1uxin" on discord if you have any questions or anything I'm normally pretty active, and enjoy!
-- If you want to redistribute/share these files please add and dm "f1uxin" on discord to talk more, me and my friend pay for these games with our own money, we do get games cheaper but its still money that we have and are spending so it sucks when people steal/don't credit me at all.

-- P.S On some socials you may find another person with a close name to me, its "f1uxin sells" or "f1uxins shop" any accounts like that are not mine, i do not sell anything, everything I show is free.

-- P.S. #2. This one is important, you see the "setManifestid" lines below right? If you want your game to "auto update" put "--" without the "" Infront of each "setManifestid" or you can completely remove those lines but that is not recommended, then just save this file, and add it however you add mani & lua files. Example "--setManifestid"

-- Guns.lol link (guns.lol is like linktree, its just my socials) : https://guns.lol/f1uxin


-- MAIN APPLICATION
addappid(1222690)
addappid(228982)
setManifestid(228982,"6413394087650432851")
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(1222691,0,"542701533d6c8db0061f50ecbd1590287c2dfef83d7999818dda3ba8d49c113b")
setManifestid(1222691,"6654432343229856467")
addappid(1222692,0,"69f743c2364a5096480dee7c15cdf6ac1c8bf03c7e43f0c839eeaef83acd66ab")
setManifestid(1222692,"6782715373837024450")
addappid(1222693,0,"6010c7f30ae23cd27519e564c780f4376295379ccbc9c8cac48eb86df1808fab")
setManifestid(1222693,"4477377153769853743")
addappid(1222694,0,"80e38ca64c882fb113d00e552ec4aaed9cfe242cbc6d86352835cd1f13f6c81f")
setManifestid(1222694,"5377366431222581978")
addappid(1222695,0,"21af62561edab8c5e1b0241759ed5fd4b9638979306e35fdb7f47158ec3c783a")
setManifestid(1222695,"70935508773482976")
addappid(1222696,0,"2586e4ff645fbc003677e5d784d151e65f20f3282777762778e4ccfdf29fcc90")
setManifestid(1222696,"3068631165780452944")
addappid(1222697,0,"325a200cc63eb34501ead298fd72b6356056323c57f5c9696f3da4c7ecd05a5b")
setManifestid(1222697,"4293670062284233606")
addappid(1222698,0,"b89fb629cfe864d87c182ae86c8510163a4d419543795f458ecae9f06557a9b1")
setManifestid(1222698,"3237415883364299210")
addappid(1222699,0,"66fbe2cea0a5c2ae0b0a02e7c525373596cfe5e51bea8535221782fb9f656103")
setManifestid(1222699,"3926603483185551847")
addappid(1257169,0,"55ef26436f62c1abd06bd35e3dac4826f8b7ebcedd9e7242eb671600e99773bb")
setManifestid(1257169,"4029381353892289467")