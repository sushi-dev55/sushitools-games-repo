-- Made by @f1uxin, If you would like to check out my discord server here's a link : https://discord.gg/NmmpgnAgen
-- In my server we help with mani & lua files, fixes, and honestly just anything about piracy,
-- You can dm me "f1uxin" on discord if you have any questions or anything I'm normally pretty active, and enjoy!
-- If you want to redistribute/share these files please add and dm "f1uxin" on discord to talk more, me and my friend pay for these games with our own money, we do get games cheaper but its still money that we have and are spending so it sucks when people steal/don't credit me at all.

-- P.S On some socials you may find another person with a close name to me, its "f1uxin sells" or "f1uxins shop" any accounts like that are not mine, i do not sell anything, everything I show is free.

-- P.S. #2. This one is important, you see the "setManifestid" lines below right? If you want your game to "auto update" put "--" without the "" Infront of each "setManifestid" or you can completely remove those lines but that is not recommended, then just save this file, and add it however you add mani & lua files. Example "--setManifestid"

-- Guns.lol link (guns.lol is like linktree, its just my socials) : https://guns.lol/f1uxin


-- MAIN APPLICATION
addappid(1174180)
addappid(1190050)
addappid(1190051)
addappid(1174181,0,"6fbf0f4b33fd5111d0832f0fb63a4d185c5321901ef95776c73e6e10b203bc25")
setManifestid(1174181,"4757128409362785099")
addappid(1174182,0,"0824e4e00b9d464a1352b0eaa60416ee3bfe0f3b416459991dc6fca87e84366f")
setManifestid(1174182,"2258488483491377476")
addappid(1174183,0,"cd51ee7e8adde797736bc283f9d434fae0aac28753e3f38a29a78aac298c0ccf")
setManifestid(1174183,"4785346550216140531")
addappid(1174184,0,"506c8f971b77f5c39f8baa54fac090e79bf32e19d92eca2a34cba9569bbe5d8a")
setManifestid(1174184,"2698939236196220127")
addappid(1174185,0,"6fe9c5b4e41f1f91b6a775dd562515e9652570cc607caedef2bc4a9d522fea4d")
setManifestid(1174185,"8173342615013177810")
addappid(1174186,0,"0ef7331ad866994474a72131eeb1a5667dc8c9f7be87b4e1d805f288e1d49432")
setManifestid(1174186,"357926288062992323")
addappid(1899671,0,"b7921da5e50d00b2238d0fe870a354cb572bc5d397955fef02a439103f62827b")
setManifestid(1899671,"6894431991641066272")