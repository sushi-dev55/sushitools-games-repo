-- Made by F1uxin, Discord ID:965053505901588521 | Discord Server (TGP | The Galaxy of Pirates): https://discord.gg/VfCxRsFyFe

-- If you're interested in distributing these files please dm me on discord (UserID:965053505901588521) 
-- (I don't care if you send them to a friend or to help someone, just if you add them in your bot or have them widely available then i would like to know.)

-- Socials: https://guns.lol/f1uxin

-- If you have any questions feel free to dm on discord (UserID:965053505901588521)


-- Main stuff to actually add the game, DLCs, & depots.
addappid(2212330, 1, "ae8d00624a011513a63c94559f3f43ccd7ed3365d150f67d72b840aae7378b3d") -- Your Only Move Is HUSTLE
addappid(2232859, 1, "05957eaa75916b9cbb777a42bcdbe65e7652478e4d8a6fb3549a5716d1ba984a") -- Depot 2232859
setManifestid(2232859, "8155394999742219200", 121860208)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)