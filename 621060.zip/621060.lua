-- Made by @f1uxin, If you would like to check out my discord server here's a link : https://discord.gg/NmmpgnAgen
-- In my server we help with mani & lua files, fixes, and honestly just anything about piracy,
-- You can dm me "f1uxin" on discord if you have any questions or anything I'm normally pretty active, and enjoy!
-- If you want to redistribute/share these files please add and dm "f1uxin" on discord to talk more, me and my friend pay for these games with our own money, we do get games cheaper but its still money that we have and are spending so it sucks when people steal/don't credit me at all.

-- P.S On some socials you may find another person with a close name to me, its "f1uxin sells" or "f1uxins shop" any accounts like that are not mine, i do not sell anything, everything I show is free.

-- P.S. #2. This one is important, you see the "setManifestid" lines below right? If you want your game to "auto update" put "--" without the "" Infront of each "setManifestid" or you can completely remove those lines but that is not recommended, then just save this file, and add it however you add mani & lua files. Example "--setManifestid"

-- Guns.lol link (guns.lol is like linktree, its just my socials) : https://guns.lol/f1uxin


-- MAIN APPLICATION
addappid(621060)
addappid(621060,0,"a8ecc84565d7b4f97cbe6a4c1cdd06169a0066fdaf9e0221a24b0ca7c3d9b45e")
addappid(973911,0,"a8d8b7263cd12d4e507235de6387d9836de57c8b5db216718fc39efd10ce4fa3")
setManifestid(973911,"2685826651630361507")
addappid(973913,0,"158dc9df98251a4f530488d790133a004eca4e54662ce3af07e281d09877ccf6")
setManifestid(973913,"5196682258430873488")
addappid(982601,0,"c139ec855f8d547eca7c9a7cf04684b233ad77dcf7b3eb1cde27e72653620522")
setManifestid(982601,"5563936077417057939")
addappid(823721,0,"df05eaae0ca49058c5fa7ded79d21ac2171492bedd24043a4e20c0f481046f87")
setManifestid(823721,"1129732127197775673")
addappid(1067591,0,"6f7750fbf846134738d1cc1217eb3fd4c3b2ab8b01b72632418bab461bd567a9")
setManifestid(1067591,"4596798953497399210")
addappid(621064,0,"99c73cc41569fc2a0dcf0a31e01100910dbc13d02796e59d4690779c435b3e69")
setManifestid(621064,"7462877534655878177")
addappid(1252991,0,"81f5c96180e9d56dc4420bc2a12234569b73ee31ed2f2caa32cb7e0f6c64422e")
setManifestid(1252991,"5962469216062900967")
addappid(1295801,0,"399e0f27eb31954c73fd4dab64bc4bdf6f9f52296c83dd359c9b5701d30cd883")
setManifestid(1295801,"1453017817142136898")
addappid(1416671,0,"5009289fe0dffa35b19502e8a4c051eba4c86568544c752b14f9bc45893755a3")
setManifestid(1416671,"7591920544321803732")
addappid(1591921,0,"fdc918ec5412354aac886f088b9effeba01f8cd808aca3b20ac8d1cea92aae26")
setManifestid(1591921,"7737755154255796550")
addappid(621066,0,"3f4ffa558cfb78f1d55d918c35023414f578b0e4e5bb46521b5e6bccf312e5fe")
setManifestid(621066,"2389478938334206964")
addappid(621061,0,"1d1b57e233552bf36e85de21663fda41d1160d3d446649bf0f1013a8d344ef01")
setManifestid(621061,"8059996378040224226")
addappid(621062,0,"d762715b8415a1f887f261e5a1736c7e86ad1fe5f77d2e945fcd61b255689df4")
setManifestid(621062,"5241418081171311864")