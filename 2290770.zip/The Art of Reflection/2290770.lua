-- 2290770's Lua and Manifest Created by Morrenus
-- The Art of Reflection
-- Created: December 04, 2025 at 06:36:54 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2290770) -- The Art of Reflection
-- MAIN APP DEPOTS
addappid(2290772, 1, "b0f8fe9d558cd114f5b4fb8afc8cf9633f57d3e873b83e1f731928202080a777") -- Depot 2290772
setManifestid(2290772, "1507054788246342955", 1371233723)