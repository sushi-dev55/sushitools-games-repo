-- Made by @f1uxin, If you would like to check out my discord server here's a link : https://discord.gg/NmmpgnAgen
-- In my server we help with mani & lua files, fixes, and honestly just anything about piracy,
-- You can dm me "f1uxin" on discord if you have any questions or anything I'm normally pretty active, and enjoy!
-- If you want to redistribute/share these files please add and dm "f1uxin" on discord to talk more, me and my friend pay for these games with our own money, we do get games cheaper but its still money that we have and are spending so it sucks when people steal/don't credit me at all.

-- P.S On some socials you may find another person with a close name to me, its "f1uxin sells" or "f1uxins shop" any accounts like that are not mine, i do not sell anything, everything I show is free.

-- P.S. #2. This one is important, you see the "setManifestid" lines below right? If you want your game to "auto update" put "--" without the "" Infront of each "setManifestid" or you can completely remove those lines but that is not recommended, then just save this file, and add it however you add mani & lua files. Example "--setManifestid"

-- Guns.lol link (guns.lol is like linktree, its just my socials) : https://guns.lol/f1uxin


-- MAIN APPLICATION
addappid(472870)
addappid(472871,0,"3840b67289bf6bf1ff4d211ce84dfdbb312f8cb2445e94d81db7ab6c841219d2")
setManifestid(472871,"7768828227208668591")
addappid(472872,0,"2cd7e9e960d9b27f9a59325c0223d53a76b4bd8f16ead3c12f7cbc25a28f3b7a")
setManifestid(472872,"5318254563348525451")
addappid(472873,0,"459ed1964b752ca24bea68ac4b46f1539f60021dd6c5c6ff44c3da804fd3e000")
setManifestid(472873,"6285717924211150026")