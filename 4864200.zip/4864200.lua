-- Made by F1uxin, Discord ID:965053505901588521 | Discord Server (TGP | The Galaxy of Pirates): https://discord.gg/VfCxRsFyFe

-- If you're interested in distributing these files please dm me on discord (UserID:965053505901588521) 
-- (I don't care if you send them to a friend or to help someone, just if you add them in your bot or have them widely available then i would like to know.)

-- Socials: https://guns.lol/f1uxin

-- If you have any questions feel free to dm on discord (UserID:965053505901588521)


-- Main stuff to actually add the game, DLCs, & depots.
addappid(4864200) -- Grandpa's Euchre
addappid(4864201, 1, "003b2fe5652ab10bfbb804a5f3c64c5f940fed4eb57288a1166dd0bc519ff27d") -- Depot 4864201
--setManifestid(4864201, "2136740702912523658", 183273060)