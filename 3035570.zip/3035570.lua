-- Made by @f1uxin, If you would like to check out my discord server here's a link : https://discord.gg/NmmpgnAgen
-- In my server we help with mani & lua files, fixes, and honestly just anything about piracy,
-- You can dm me "f1uxin" on discord if you have any questions or anything I'm normally pretty active, and enjoy!
-- If you want to redistribute/share these files please add and dm "f1uxin" on discord to talk more, me and my friend pay for these games with our own money, we do get games cheaper but its still money that we have and are spending so it sucks when people steal/don't credit me at all.

-- P.S On some socials you may find another person with a close name to me, its "f1uxin sells" or "f1uxins shop" any accounts like that are not mine, i do not sell anything, everything I show is free.

-- P.S. #2. This one is important, you see the "setManifestid" lines below right? If you want your game to "auto update" put "--" without the "" Infront of each "setManifestid" or you can completely remove those lines but that is not recommended, then just save this file, and add it however you add mani & lua files. Example "--setManifestid"

-- Guns.lol link (guns.lol is like linktree, its just my socials) : https://guns.lol/f1uxin


-- MAIN APPLICATION
addappid(3035570, 1, "4c91c360d9bed6825d91da09c62ea023e9caa5c94b6639bbe174d738b137a941") 
addappid(3035571, 1, "e5d6ddfebd010fdb77b506a1d38d0c9a8929e5da7e35d812cc31b60996765be8")
setManifestid(3035571, "7701461256988246108", 66675361117)
addappid(3035572, 1, "6b8ab5f02c19f579e70f727bf5cf334dd677f79ce53f00d872838e45f5be8ff4") 
setManifestid(3035572, "3845134517469659789", 392254898)
addappid(3035573, 1, "0d3898c52be7bac07b224983d013dc1dc7f5604d012d8acf53705f27b2407f93")
setManifestid(3035573, "5351335579227766358", 439322232)
addappid(3035574, 1, "5fd1b7a0fcd0358604b077b36916c25306f56a02711bc81340adc8f931c14069") 
setManifestid(3035574, "2148555373227341127", 379770482)
addappid(3035575, 1, "bea37d2097d85084367b1081b989393012083fcc6645ce27cfa030594d99b8e4") 
setManifestid(3035575, "123013753023180286", 377570186)
addappid(3035576, 1, "f3b973f43336ffe5eb19bf1005af5b1dd85c5549fb2d8bcffdbae21ad0ebcc49") 
setManifestid(3035576, "694653800485836473", 407755875)
addappid(3035577, 1, "78c5bd2ce6e71c7bd10040111312fdb376ff42e7ba46acb57e99e0b9804c38a5") 
setManifestid(3035577, "2250655009717463561", 363639418)
addappid(3035578, 1, "a9edaf32fd28a1a2604b861adfd73d2cac3368a9db1699dafed5634581bd3986")
setManifestid(3035578, "7298492144403511848", 369289959)
addappid(3035579, 1, "3fbd2da5efa4409f73ddbb97d7be0ca837c1d277ec0fc2a919071a6069f64333") 
setManifestid(3035579, "5211244630068237437", 393839201)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") 
setManifestid(228988, "6645201662696499616", 29212173)
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") 
setManifestid(1716751, "4835530931043548961", 259065496)
addappid(3035580) 
addappid(3230570) 
addappid(3230580) 
addappid(3230590) 
addappid(3230600) 
addappid(3230610) 
addappid(3230620) 
addappid(3230630) 
addappid(3230640) 
addappid(3230650) 
addappid(3230660) 
addappid(3230670) 
addappid(3230680) 
addappid(3230690) 
addappid(3230700) 
addappid(3230710) 
addappid(3230720) 
addappid(3230730) 
addappid(3230740) 
addappid(3230750) 
addappid(3230760) 
addappid(4145490) 
addappid(4145500) 
addappid(4145510) 
addappid(4145520) 