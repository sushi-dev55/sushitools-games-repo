-- 2923350's Lua and Manifest Created by Morrenus
-- Ultimate Sheep Raccoon
-- Created: December 09, 2025 at 17:25:42 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2923350) -- Ultimate Sheep Raccoon
-- MAIN APP DEPOTS
addappid(2923351, 1, "c9464aad5a057b265d9835a3425920410578a8370c565695ff6c206c898b0001") -- Depot 2923351
setManifestid(2923351, "4477440554083422954", 2778182117)