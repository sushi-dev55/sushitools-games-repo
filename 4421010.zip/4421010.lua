-- Made by F1uxin, Discord ID:965053505901588521 | Discord Server (TGP | The Galaxy of Pirates): https://discord.gg/VfCxRsFyFe

-- If you're interested in distributing these files please dm me on discord (UserID:965053505901588521) 
-- (I don't care if you send them to a friend or to help someone, just if you add them in your bot or have them widely available then i would like to know.)

-- Socials: https://guns.lol/f1uxin

-- If you have any questions feel free to dm on discord (UserID:965053505901588521)


-- Main stuff to actually add the game, DLCs, & depots.
addappid(4421010, 1, "d4498a5e8f21f1b5d64df4737a56df8d5dcb372982757215170308a33112d914") -- Bills Must Be Paid
addappid(4421011, 1, "11e5390201ab27a5ff5ccd0a0c03136ba3b4e50f0c08b187d14b36a2a23896d6") -- Depot 4421011
--setManifestid(4421011, "6848976417670468762", 1467445905)
addappid(4421012, 1, "59e5144afe91bf9c7914f4df2297cdb42b37b584ee885cbbc7f8b4fd6155a156") -- Depot 4421012
--setManifestid(4421012, "4644916239143317778", 1598762135)
addappid(5020040) -- Bills Must Be Paid - Supporter Pack