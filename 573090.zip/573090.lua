-- Made by F1uxin, Discord ID:965053505901588521 | Discord Server (TGP | The Galaxy of Pirates): https://discord.gg/VfCxRsFyFe

-- If you're interested in distributing these files please dm me on discord (UserID:965053505901588521) 
-- (I don't care if you send them to a friend or to help someone, just if you add them in your bot or have them widely available then i would like to know.)

-- Socials: https://guns.lol/f1uxin

-- If you have any questions feel free to dm on discord (UserID:965053505901588521)


-- Main stuff to actually add the game, DLCs, & depots.
addappid(573090, 1, "1385435ae44e48ac0fbea684d525581b864dd6e984b1469e68e029f37e820052") -- Stormworks: Build and Rescue
addappid(573091, 1, "49f609573f8fc3923ec4eab2ba459bdea77b7a906e9054549c102e4659fcfff7") -- Stormworks Content Win32
--setManifestid(573091, "8112475939258206235", 2268955902)
addappid(573092, 1, "871725b4b4314590b50465afe4c8ebd3cea63a704afce1ae1f369edecb0be7f5") -- Stormworks Content MacOS
--setManifestid(573092, "6821711083533180298", 1331712438)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
--setManifestid(228985, "3966345552745568756", 13699237)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
--setManifestid(228988, "6645201662696499616", 29212173)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- OpenAL 2.0.7.0 Redist (Shared from App 228980)
--setManifestid(229020, "5799761707845834510", 810085)
addappid(1542360) -- Stormworks Search and Destroy
addappid(2124750) -- Stormworks Industry
addappid(2383250) -- Stormworks Space