-- 2439560's Lua and Manifest Created by Morrenus
-- Alice's World
-- Created: November 29, 2025 at 15:00:47 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2439560) -- Alice's World
-- MAIN APP DEPOTS
addappid(2439561, 1, "a83154b16e91f66022956079e5ec81a27c71d8ade0a7cbbf6171d915fe7965b2") -- Depot 2439561
setManifestid(2439561, "4820983002941027353", 2555358158)