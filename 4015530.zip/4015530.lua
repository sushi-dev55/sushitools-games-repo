-- 4015530's Lua and Manifest Created by Morrenus
-- MyVoiceZoo
-- Created: December 13, 2025 at 08:50:00 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4015530) -- MyVoiceZoo
-- MAIN APP DEPOTS
addappid(4015531, 1, "b560c7cd9497b0a08b869cd05ee3314e848c16967d2389b02efb45d57a112ff4") -- Depot 4015531
setManifestid(4015531, "2080051816750499532", 304408739)