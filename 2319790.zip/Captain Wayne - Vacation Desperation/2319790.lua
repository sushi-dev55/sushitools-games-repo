-- 2319790's Lua and Manifest Created by Morrenus
-- Captain Wayne - Vacation Desperation
-- Created: November 29, 2025 at 05:59:39 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2319790) -- Captain Wayne - Vacation Desperation
-- MAIN APP DEPOTS
addappid(2319791, 1, "3a1f69fd013ffc978c79810d64ff3cc67ea729388a870c63f55b2c63268c4488") -- Depot 2319791
setManifestid(2319791, "1283969765421118223", 629578572)