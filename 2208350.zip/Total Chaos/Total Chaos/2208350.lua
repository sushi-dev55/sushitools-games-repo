-- 2208350's Lua and Manifest Created by Morrenus
-- Total Chaos
-- Created: November 21, 2025 at 04:07:11 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2208350) -- Total Chaos
-- MAIN APP DEPOTS
addappid(2208351, 1, "f89145057d0fc47ccfafc6f127d9a151704248d818381e1fd71c03e5124b81fb") -- Depot 2208351
setManifestid(2208351, "4478590216641040066", 22693825729)