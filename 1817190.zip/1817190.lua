-- Made by @f1uxin, If you would like to check out my discord server here's a link : https://discord.gg/NmmpgnAgen
-- In my server we help with mani & lua files, fixes, and honestly just anything about piracy,
-- You can dm me "f1uxin" on discord if you have any questions or anything I'm normally pretty active, and enjoy!
-- If you want to redistribute/share these files please add and dm "f1uxin" on discord to talk more, me and my friend pay for these games with our own money, we do get games cheaper but its still money that we have and are spending so it sucks when people steal/don't credit me at all.

-- P.S On some socials you may find another person with a close name to me, its "f1uxin sells" or "f1uxins shop" any accounts like that are not mine, i do not sell anything, everything I show is free.

-- P.S. #2. This one is important, you see the "setManifestid" lines below right? If you want your game to "auto update" put "--" without the "" Infront of each "setManifestid" or you can completely remove those lines but that is not recommended, then just save this file, and add it however you add mani & lua files. Example "--setManifestid"

-- Guns.lol link (guns.lol is like linktree, its just my socials) : https://guns.lol/f1uxin


-- MAIN APPLICATION
addappid(1817190)
addappid(2133610)
addappid(1817191,0,"91cea3ca7e88bc7c2996ff596e0265f6f08725039231fbb3c690de1392123557")
setManifestid(1817191,"3147410455635656654")
addappid(1817192,0,"0dbff607360baee47d8b9758bb4eaf1c06cdc2f05a3928cd4b63f3095a01bdc5")
setManifestid(1817192,"6194380709246954205")
addappid(1817194,0,"36182530fb130e8fe36c418f8cbe1f3c4d80612ed2238f2b6e2de6ac5379c8fc")
setManifestid(1817194,"5377748227570864319")
addappid(1817195,0,"6960ae982ba686f92440369d386066936bc5088932ec01f78e4e18be555c7eaf")
setManifestid(1817195,"5810006367820443622")
addappid(1817196,0,"395523caf7a1bb235e3b9010c83eeb0b6b39de83d2a5139ebde080c9e5d8b86f")
setManifestid(1817196,"8292041091951368180")
addappid(1817197,0,"0e3f3259d54c63dda0bffaf8db48e1c6ac2cc6a7a3269040f55753d49c30f239")
setManifestid(1817197,"8895962896721290161")
addappid(1817198,0,"d4dda3222d171b9eed3ae4b40f5f93fbeb0c70932717bed1f930ee7008c7a3e4")
setManifestid(1817198,"3531441267696901814")
addappid(1817199,0,"32929006ffff16e880e14785d0c37fb4d1873915be592b8f0ff562cc4df13fca")
setManifestid(1817199,"8758386880563899064")
addappid(1829900,0,"7e97a4469c86ce458028cbd9e97b8622f51e1f1e91e213eabd88f24cfa87ee10")
setManifestid(1829900,"436680072166473638")
addappid(1829901,0,"2c0d6bf29a266d843cb5c5621f015c589e21b095e8fe40057a31a978487ed0c5")
setManifestid(1829901,"5933996443615820417")
addappid(1829902,0,"984055093dcd964a1bcea2c9044c5edd718ec5f2c62a9c1bcd3bb17219268685")
setManifestid(1829902,"4688196650181006526")
addappid(1829903,0,"2b37a7fded4585baf99d45b5db9e89f012df9517d97b0b71662e17878bbbcc9a")
setManifestid(1829903,"7963205018761426610")
addappid(1829904,0,"23a85534d021e1f4199c44ae80869a3ff1b8b4b292efe4e1521a4de15c2595b3")
setManifestid(1829904,"4904054511197887188")
addappid(1829905,0,"3e433f1d09bb4cebf12e53928b3a6bb9a373620f5a54fa1d24a89d6ef1e55afd")
setManifestid(1829905,"3410727558182517018")