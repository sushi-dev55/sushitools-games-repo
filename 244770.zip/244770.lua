-- Made by F1uxin, Discord ID:965053505901588521 | Discord Server (TGP | The Galaxy of Pirates): https://discord.gg/VfCxRsFyFe

-- If you're interested in distributing these files please dm me on discord (UserID:965053505901588521) 
-- (I don't care if you send them to a friend or to help someone, just if you add them in your bot or have them widely available then i would like to know.)

-- Socials: https://guns.lol/f1uxin

-- If you have any questions feel free to dm on discord (UserID:965053505901588521)


-- Main stuff to actually add the game, DLCs, & depots.
addappid(244770, 1, "946e18d42f071b780550624873694809406a8db706e3839910c3e25b7e6b6591") -- StarMade
addappid(244771, 1, "0526b79f57ebe0259242910902117d60f0b809ed257d4229118a05138329cc80") -- StarMade Main
setManifestid(244771, "4023595530257797357", 694607328)
addappid(244781, 1, "9f658991f0206297e9278491f4a2eff2afcac9d758801ddc9b6a060b330790c0") -- Depot 244781
setManifestid(244781, "8459554422357604394", 116168971)
addappid(244782, 1, "928d40c12614b2db2660f4368f9ab9d2dace494da2e8821abe5547138bcd5dbb") -- Depot 244782
setManifestid(244782, "4393877860026365496", 147984512)
addappid(244783, 1, "de11c2fe20ce1c452c88d4819866a7fc673b88755d931c65f95519e72be0fe89") -- Depot 244783
setManifestid(244783, "5505119564703829733", 346373520)